package com;

import io.confluent.kafka.streams.serdes.avro.SpecificAvroSerde;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Produces;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.Produced;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.jboss.logging.annotations.Properties;
import org.jboss.logging.annotations.Property;


import java.util.HashMap;
import java.util.Map;

@ApplicationScoped
public class KStreams {


    @ConfigProperty(name = "schema-registry")
    String schemaRegistry;


    @Produces
    public Topology buildTopology() {

        Map<String, String> cfg = new HashMap<>();
        cfg.put("schema.registry.url", schemaRegistry);

        SpecificAvroSerde<AvroTest> avroDeviceSerialNumberMappingSerde = new SpecificAvroSerde<>();
        avroDeviceSerialNumberMappingSerde.configure(cfg, false);

        StreamsBuilder sb = new StreamsBuilder();

        sb
                .stream("test-in", Consumed.with(Serdes.String(), avroDeviceSerialNumberMappingSerde))
                .to("test-out", Produced.with(Serdes.String(), avroDeviceSerialNumberMappingSerde));

        return sb.build();
    }
}
